#!/bin/bash
# this wrapper is responsible for launching appropriate bmc.py listening daemons for specific VMs
# this utility is needed to simulate fake ipmi
# specific vm and api credentials are passed to local files via cloud-init

# need to wait here until cloud-init does it's thing, usually around 10 seconds.
#echo "Waiting for cloud-init to finish startup"
#sleep 15
# Not needed anymore, added After=cloud-init.service to bmc.service

# pull in $API_USERNAME and $ASPECT from cloud-init created .conf file:
#source /etc/bmc/bmc.conf
source /etc/rht
# To get ILT configuration of where the VMs are (retrieved by rc.local on boot)
[[ -f /etc/rht_vms ]] && source /etc/rht_vms

# pull $APP_NAME from /etc/ravello/vm.json provided by cloud-init
#APP_NAME=`cat /etc/ravello/vm.json | python -m json.tool | awk '/appName/ {print $2}' | sed 's/[",]//g'`

# parse /etc/bmc/vms from cloud-init to assign alias IPs:

for IPADDR in `grep -v ^\# /etc/bmc/vms | awk -F, '{print $2}'`
do
	echo -n "Adding alias IP $IPADDR...." 
	ip address add $IPADDR dev eth2 &>/dev/null
	if [ $? -eq 0 ]; then
		echo "Success"
	else
		echo "Failed"
	fi
done

# parse /etc/bmc/vms from cloud-init and launch a bmc.py thread for each VM

for VM in `grep -v ^\# /etc/bmc/vms`
do
	VM_NAME=`echo $VM | awk -F, '{print $1}'`
	ADDRESS=`echo $VM | awk -F, '{print $2}'`
        if [[ ${RHT_GVMS} == *${VM_NAME}* ]]; then
		HYPERVISOR="qemu+ssh://root@galaxy${RHT_ENROLLMENT}.ilt.example.com/system?no_verify=1"
        else
		HYPERVISOR="qemu+ssh://root@foundation${RHT_ENROLLMENT}.ilt.example.com/system?no_verify=1"
        fi
	echo "Creating IPMI proxy listener for $VM_NAME listening on ${ADDRESS}:623/udp"
	python /usr/local/bin/virshbmc.py --address $ADDRESS --port 623 --connect $HYPERVISOR --domain $VM_NAME &
	sleep 1
done

