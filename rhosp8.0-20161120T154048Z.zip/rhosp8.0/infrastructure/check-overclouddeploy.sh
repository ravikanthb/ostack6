#!/bin/bash
# The script ensures all OpenStack overcloud services are running
# and tries to create an environment with networks and an instance
PATH=/usr/bin:/bin:/usr/sbin:/sbin

run_as_root='true'
blue="\\033[1;34m"
nc='\e[0m'
ssh='ssh -o StrictHostKeyChecking=no'
scp='scp -q'

img=small
img_url=http://materials.example.com/${img}.img
flavor=m2.small
router=test_router1
priv_sub=test_privsub
pub_sub=test_pubsub
priv_net=test_privnet
pub_net=test_pubnet
key=test_key1
instance="test_overcloud"
creds=/home/stack/overcloudrc

# Enabled to prevent TTY errors
sudo sed -i -e 's/requiretty/!requiretty/' /etc/sudoers

function print_PASS() {
  [[ $# -gt 0 ]] && echo -n "$@ "
  echo -e "\\033[1;32mPASS\\033[0;39m"
  let pass_count++
}

function print_FAIL() {
  [[ $# -gt 0 ]] && echo -n "$@ "
  echo -e "\\033[1;31mFAIL\\033[0;39m"
  let fail_count++
}

function pad {
  local text="$1"
  local dots='...............................................................'
  printf '%s%s  ' "${text}" "${dots:${#text}}"
}

function lab_setup {
  echo
  echo "== Setup =="
  echo

  source ${creds}
  compute_ip=$(openstack server list | awk '/novacompute/ {print $8}' | cut -d = -f 2)
  controller_ip=$(openstack server list | awk '/controller/ {print $8}' | cut -d = -f 2)
  ceph_ip=$(openstack server list | awk '/cephstorage/ {print $8}' | cut -d = -f 2)

  for server in $(${compute_ip} ${controller_ip} ${ceph_ip}) ; do
    if [[ ! -z ${server} ]]; then
      echo "${server} is missing"
      exit 1
    fi
  done
}

function test_command {
  cmd=$1
  message=$2
  pad " . ${message}"
  if ${cmd} &>/dev/null; then
    print_PASS
    return 1
  else
    print_FAIL
    return 0
  fi
}
function check_services {
  openstack_services=(
    neutron-dhcp-agent.service
    neutron-openvswitch-agent.service
    neutron-server.service
    openstack-ceilometer-alarm-evaluator.service
    openstack-ceilometer-alarm-notifier.service
    openstack-ceilometer-api.service
    openstack-ceilometer-central.service
    openstack-ceilometer-collector.service
    openstack-ceilometer-notification.service
    openstack-glance-api.service
    openstack-glance-registry.service
    openstack-heat-api-cfn.service
    openstack-heat-api-cloudwatch.service
    openstack-heat-api.service
    openstack-heat-engine.service
    openstack-ironic-api.service
    openstack-ironic-conductor.service
    openstack-ironic-inspector-dnsmasq.service
    openstack-ironic-inspector.service
    openstack-nova-api.service
    openstack-nova-cert.service
    openstack-nova-compute.service
    openstack-nova-conductor.service
    openstack-nova-scheduler.service
  )

  for i in "${openstack_services[@]}"; do
    pad " . Checking $i"
    service=$(sudo systemctl is-active $i | grep -q ^active)
    if systemctl is-active $i &>/dev/null; then
      print_PASS
    else
      print_FAIL
      pad " . Attempting to start $i"
      sudo systemctl start $i &>/dev/null
    fi
  done
}

function lab_cleanup {
  echo
  echo "== Cleanup =="
  echo
  source ${creds}

  if openstack server list | grep -q ${instance}; then
    test_command "openstack server delete ${instance}" "Removing instance"
  fi
  if openstack flavor list | grep -q ${flavor}; then
    flavor_id=$(openstack flavor list | awk "/${flavor}/ {print \$2}")
    test_command "nova flavor-delete ${flavor_id}" "Removing flavor"
  fi
  if openstack image list | grep -q ${img}; then
    test_command "openstack image delete ${img}" "Removing image"
  fi
  if openstack keypair list | grep -q ${key}; then
    test_command "openstack keypair delete ${key}" "Removing keypair"
    rm -f ~/${key}.pem
  fi

  pad " . Removing floating IPs"
  for i in $(openstack ip floating list | grep -v -e '| ID' -e + | awk '{print $2}' ); do
    openstack ip floating delete $i
    openstack ip floating list | grep -q $i
    while [[ $? -ne 1 ]]; do
      sleep 3
      openstack ip floating list | grep -q $i
    done
  done
  print_PASS

  pad " . Removing router"
  for i in $(neutron router-list | grep -v -e '| id' -e + | awk '{print $2}'); do
    for j in $(neutron router-port-list $i | grep -v -e '| id' -e + | cut -d '"' -f 4 ); do
      neutron router-interface-delete $i $j &>/dev/null
    done
    neutron router-gateway-clear $i &>/dev/null
    neutron router-delete $i &>/dev/null
    neutron router-list | grep -q $i
    while [[ $? -ne 1 ]]; do
      sleep 3
      neutron router-list | grep -q $i
    done
  done
  print_PASS

  pad " . Removing networks"
  for i in $(neutron net-list | grep -v -e '| id' -e + | awk '{print $2}' ); do
    neutron net-delete $i > /dev/null
    neutron net-list | grep -q $i
    while [[ $? -ne 1 ]]; do
      sleep 3
      neutron net-list | grep -q $i
    done
  done
  print_PASS

  if openstack security group rule list default | grep -q icmp; then
    rule=$(openstack security group rule list default | awk '/icmp/ {print $2}')
    test_command "openstack security group rule delete ${rule}" "Removing ICMP rule"
  fi
  if openstack security group rule list default | grep -q 22:22; then
    rule=$(openstack security group rule list default | awk '/22:22/ {print $2}')
    test_command "openstack security group rule delete ${rule}" "Removing SSH rule"
  fi
}

function lab_provision {
  lab_cleanup
  echo
  echo "== Provision =="
  echo
  source ${creds}

  test_command "openstack flavor create --ram 1024 --disk 10 --swap 1 --vcpus 2 --public ${flavor}" "Creating flavor"

  wget ${img_url} &>/dev/null
  test_command "openstack image create --disk-format qcow2 --container-format bare --file ${img}.img --public ${img}" "Importing image"
  rm -f ${img}.img

  pad " . Creating keypair"
  if openstack keypair create ${key} > ~/${key}.pem; then
    print_PASS
    chmod 600 /home/stack/${key}.pem &>/dev/null
  else
    print_FAIL
  fi

  pad ' . Creating public network'
  if neutron net-create ${pub_net} &>/dev/null; then
    print_PASS
    test_command "neutron net-create ${priv_net}" "Creating private network"
  else
    print_FAIL
  fi

  pad ' . Creating private subnet'
  if neutron subnet-create --name ${priv_sub} --gateway 192.168.1.5 --allocation-pool start=192.168.1.15,end=192.168.1.20 --dns-nameserver 172.25.254.254 --enable-dhcp ${priv_net} 192.168.1.0/24 &>/dev/null; then
    print_PASS
    test_command "neutron subnet-create --name ${pub_sub} --gateway 172.25.250.254 --allocation-pool start=172.25.250.50,end=172.25.250.60 --dns-nameserver 172.25.254.254 --disable-dhcp ${pub_net} 172.25.250.0/24" "Creating public subnet"
  else
    print_FAIL
  fi

  pad ' . Configuring router'
  if neutron router-create ${router} &>/dev/null; then
    if neutron net-update --router:external ${pub_net} &>/dev/null; then
      if neutron router-gateway-set ${router} ${pub_net} &>/dev/null; then
        print_PASS
        test_command "neutron router-interface-add ${router} ${priv_sub}" "Connecting router"
      else
        print_FAIL
      fi
    else
      print_FAIL
    fi
  else
    print_FAIL
  fi

  test_command "openstack security group rule create --proto icmp --src-ip 0.0.0.0/0 --dst-port -1 default" "Allowing ICMP"
  test_command "openstack security group rule create --proto tcp --src-ip 0.0.0.0/0 --dst-port 22:22 default" "Allowing SSH"
  test_command "openstack ip floating create ${pub_net}" "Adding floating IP"
  test_command "openstack server create --image ${img} --key-name ${key} --flavor ${flavor} --nic net-id=${priv_net} --wait ${instance}" "Spawning instance"
  flt_IP=$(openstack ip floating list | grep 172.25 | awk '{print $6}' | head)
  test_command "openstack ip floating add ${flt_IP} ${instance}" "Attaching a floating IP"

}

function lab_test {
  echo
  echo "== Test =="
  echo
  source ${creds}
  instance_ip=$(nova list | awk "/${instance}/ {print \$13}")
  pad " . Waiting for the SSH connection to be available"
  while ! ssh -q -q -o BatchMode=yes -o StrictHostKeyChecking=no -o ConnectTimeout=5 -i ~/${key}.pem cloud-user@${instance_ip} exit; do
    sleep 3;
  done
  print_PASS

  pad ' . Testing SSH'
  if ${ssh} -i ~/${key}.pem cloud-user@${instance_ip} exit; then
    print_PASS
    pad ' . Trying to ping the classroom server from the instance'
    if ${ssh} -i ~/${key}.pem cloud-user@${instance_ip} ping -c 1 classroom.example.com &>/dev/null; then
      print_PASS
      lab_cleanup
    else
      print_FAIL
    fi
  else
    print_FAIL
  fi
}

check_services
lab_setup
lab_provision
lab_test