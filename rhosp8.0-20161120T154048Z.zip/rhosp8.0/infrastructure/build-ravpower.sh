#!/bin/bash
##Run this from power.lab.example.com

## Tweaks for Bowe
yum -y localinstall rhtbmc-1-*.rpm
F=/usr/local/bin/bmc-wrap.bash
[[ ! -e ${F} ]] && cp ${F} ${F}.stock
cp /usr/share/doc/rhtbmc/bmc-wrap.bash /usr/local/bin/bmc-wrap.bash

sed -i -e "/^#After.*/s/#//" /etc/systemd/system/bmc.service
sed -i -e "/^Type=/s/forking/simple/" /etc/systemd/system/bmc.service

systemctl daemon-reload
systemctl enable cloud-final


# Power down when done
#poweroff
