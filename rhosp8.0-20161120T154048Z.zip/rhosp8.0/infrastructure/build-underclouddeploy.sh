#!/bin/bash
##Run this from director.lab.example.com

target='director'
ssh='ssh -o StrictHostKeyChecking=no'
DIRECTOR='director'
local_ip='172.25.250.10/24'
undercloud_public_vip=172.25.250.110
undercloud_admin_vip=172.25.250.111
local_interface=eth0
masquerade_network='172.25.250.0/24'
dhcp_start=172.25.250.20
dhcp_end=172.25.250.30
network_cidr='172.25.250.0/24'
network_gateway=172.25.250.10
inspection_iprange='172.25.250.150,172.25.250.180'

# Replace rc.local
echo " . Replacing the rc.local"
curl -f -o /etc/rc.d/rc.local-cl210 http://content.example.com/courses/cl210/rhosp8.0/infrastructure/cl210-director-rc.local
chmod +x /etc/rc.d/rc.local-cl210
ln -sf rc.local-cl210 /etc/rc.d/rc.local

# Re-seal the image (so it will re-run rc.local)
echo " . Resealing the image"
## Clear out /etc/rht
echo -e "RHT_VENUE=ilt\nRHT_ROLE=server\nRHT_ENROLLMENT=\nRHT_COURSE=\nRHT_TITLE=\nRHT_VMTREE=rhel7.2/x86_64\nRHT_NETWORK=no" > /etc/rht

# Run new rc.local
echo " . Repersonalizing the image"
source /etc/rc.d/rc.local

# Disable strict host key checking in ssh for root
echo -e "\tStrictHostKeyChecking=no" >> /etc/ssh/ssh_config

echo " . Checking the provisioning network"
checkpxenet='[[ ! -f /etc/sysconfig/network-scripts/ifcfg-eth0 ]]'
if ${checkpxenet} &> /dev/null
then
echo -ne '\n'
  echo "  . not found - create and configure ifcfg-eth0"; exit
fi
echo -ne '\n'

echo " . Checking for software repositories"
cd /etc/yum.repos.d; curl -s -O http://materials.example.com/openstack.repo && curl -s -O http://materials.example.com/ceph.repo && curl -s -O http://materials.example.com/rhel-updates.repo
cd /etc/yum.repos.d; sed -i -e '/\[OSdirector\]/,/^\[/s/enabled=0/enabled=1/' ./openstack.repo; sed -i -e '/\[CephInstaller\]/,/^\[/s/enabled=0/enabled=1/' -e '/\[CephTools\]/,/^\[/s/enabled=0/enabled=1/' -e '/\[CephMon\]/,/^\[/s/enabled=0/enabled=1/' -e '/\[CephOsd\]/,/^\[/s/enabled=0/enabled=1/' ./ceph.repo &>/dev/null

echo -ne '\n'
echo -n " . Installing the required packages"
##Spinner
while true;do for s in / - \\ \|; do printf "\r$s";sleep 1;done;done &
trap 'kill $!' SIGTERM SIGKILL
##
yum -y install python-tripleoclient openstack-utils openstack-dashboard openstack-tempest-liberty &> /dev/null
##Kill the spinner
kill $!

echo;echo -e "\n . Creating local user stack"
id -u stack &>/dev/null || useradd stack &> /dev/null
echo redhat | passwd stack --stdin &> /dev/null

echo -ne '\n'
echo " . Giving stack user full privileges"
echo "stack ALL=(root) NOPASSWD:ALL" | tee -a /etc/sudoers.d/stack &> /dev/null
sed -i -e 's/  requiretty/  !requiretty/' /etc/sudoers
chmod 0440 /etc/sudoers.d/stack &> /dev/null

echo -ne '\n'
echo " . Creating the undercloud configuration file";echo -ne '\n'
su - stack &>/dev/null<<EOF
cp /usr/share/instack-undercloud/undercloud.conf /home/stack/undercloud.conf &> /dev/null
openstack-config --set undercloud.conf DEFAULT local_ip ${local_ip}
openstack-config --set undercloud.conf DEFAULT undercloud_public_vip ${undercloud_public_vip}
openstack-config --set undercloud.conf DEFAULT undercloud_admin_vip ${undercloud_admin_vip}
openstack-config --set undercloud.conf DEFAULT local_interface ${local_interface}
openstack-config --set undercloud.conf DEFAULT masquerade_network ${masquerade_network}
openstack-config --set undercloud.conf DEFAULT dhcp_start ${dhcp_start}
openstack-config --set undercloud.conf DEFAULT dhcp_end ${dhcp_end}
openstack-config --set undercloud.conf DEFAULT network_cidr ${network_cidr}
openstack-config --set undercloud.conf DEFAULT network_gateway ${network_gateway}
openstack-config --set undercloud.conf DEFAULT inspection_iprange ${inspection_iprange}
exit
EOF

echo -n " . Deploying undercloud"
##Spinner
while true;do for s in / - \\ \|; do printf "\r$s";sleep 1;done;done &
trap 'kill $!' SIGTERM SIGKILL
##
su - stack -c "openstack undercloud install" &>/dev/null
##Kill the spinner
kill $!

if egrep "Undercloud install complete." /home/stack/.instack/install-undercloud.log &> /dev/null
then
  echo;echo -e "\n . Setting restart on failure"
  # https://bugzilla.redhat.com/show_bug.cgi?id=1188198
  mkdir -p /etc/systemd/system/neutron-server.service.d
  echo -e "[Service]\nRestart=on-failure" > /etc/systemd/system/neutron-server.service.d/restart.conf
  echo;echo -e "\n . Setting MTU"
  echo 'MTU="1450"' >> /etc/sysconfig/network-scripts/ifcfg-eth0
  ip link set dev eth0 mtu 1450
  echo "dhcp-option=26,1450" >> /etc/dhcpmasq-ironic.conf
  echo "dhcp-option=26,1450" >> /etc/ironic-inspector/dnsmasq.conf
  systemctl restart openstack-ironic-inspector-dnsmasq.service
  systemctl restart openstack-ironic-inspector.service
  echo;echo -e "\nCongrats!! Undercloud installation done."
else
  echo;echo -e "\nArgh!! looks like it encountered some errors."
fi

# Change it back to requiretty
# RM: Breaks the grade
# sed -i -e 's/requiretty/!requiretty/' /etc/sudoers

# Reboot after install if required
# reboot;exit
