#!/bin/bash
##Run this from workstation.lab.example.com

# Set any needed variables

# ?Apply updates?

# Replace rc.local
echo " . Replacing the rc.local"
curl -f -o /etc/rc.d/rc.local-cl210 http://content.example.com/courses/cl210/rhosp8.0/infrastructure/cl210-workstation-rc.local
chmod +x /etc/rc.d/rc.local-cl210
ln -sf rc.local-cl210 /etc/rc.d/rc.local

# Re-seal the image (so it will re-run rc.local)
echo " . Resealing the image"
## Clear out /etc/rht
echo -e "RHT_VENUE=ilt\nRHT_ROLE=workstation\nRHT_ENROLLMENT=\nRHT_COURSE=\nRHT_TITLE=\nRHT_VMTREE=rhel7.2/x86_64\nRHT_NETWORK=no" > /etc/rht

# Power down when done
poweroff
