#!/bin/bash
##Run this from power.lab.example.com

# Set any needed variables

# Replace rc.local
echo " . Replacing the rc.local"
curl -f -o /etc/rc.d/rc.local-cl210 http://content.example.com/courses/cl210/rhosp8.0/infrastructure/cl210-director-rc.local
chmod +x /etc/rc.d/rc.local-cl210
ln -sf rc.local-cl210 /etc/rc.d/rc.local

# Re-seal the image (so it will re-run rc.local)
echo " . Resealing the image"
## Clear out /etc/rht
echo -e "RHT_VENUE=ilt\nRHT_ROLE=server\nRHT_ENROLLMENT=\nRHT_COURSE=\nRHT_TITLE=\nRHT_VMTREE=rhel7.2/x86_64\nRHT_NETWORK=no" > /etc/rht

# Run new rc.local
echo " . Repersonalizing the image"
source /etc/rc.d/rc.local

# Disable strict host key checking in ssh for root
echo -e "\tStrictHostKeyChecking=no" >> /etc/ssh/ssh_config

# Start Victor's script
## Activate rhel-7-server-rpms and rhel-7-server-rh-common-rpms
## Activate EPEL
echo " . Activate local and EPEL repositories"
curl -f -o /etc/yum.repos.d/rhel-updates.repo http://materials.example.com/rhel-updates.repo
#yum -y install http://download.fedoraproject.org/pub/epel/7/x86_64/e/epel-release-7-6.noarch.rpm

# Apply updates
echo " . Updating installed packages"
yum -y update

echo " . Grabbing tarball"
curl -f -o build-power.tgz http://content.example.com/courses/cl210/rhosp8.0/infrastructure/build-power.tgz
tar xvf build-power.tgz

## Install desired packages/groups
echo " . Installing desired packages"
yum -y install git
yum -y localinstall python-pip-7.1.0*.rpm
yum -y groupinstall "Development Tools"
yum -y install libvirt-client libvirt-python
yum -y install python-devel

## Install pcrypto using pip
echo " . Installing pip tools"
pip install pycrypto

## Install pyghmi, ravellobmc, and python-sdk
echo " . Installing ravello bits"
#git clone http://github.com/benoit-canet/pyghmi.git
pushd pyghmi
python setup.py install
popd
#git clone http://github.com/benoit-canet/ravellobmc.git
#pushd ravellobmc
#cp ravellobmc.py /usr/local/bin/
#popd
#git clone http://github.com/ravello/python-sdk.git
pushd python-sdk
python setup.py install
popd

## Copy files into place
mkdir /etc/bmc
curl -f -o /etc/bmc/vms http://content.example.com/courses/cl210/rhosp8.0/infrastructure/bmc-vms
curl -f -o /usr/local/bin/virshbmc.py http://content.example.com/courses/cl210/rhosp8.0/infrastructure/virshbmc.py
chmod +x /usr/local/bin/virshbmc.py
# FIXME: Retrieve ravellobmc from content
curl -f -o /usr/local/bin/bmc-wrap.bash http://content.example.com/courses/cl210/rhosp8.0/infrastructure/bmc-wrap.bash
chmod +x /usr/local/bin/bmc-wrap.bash
curl -f -o /etc/systemd/system/bmc.service http://content.example.com/courses/cl210/rhosp8.0/infrastructure/bmc.service

## Retrieve master ssh key
scp root@classroom.example.com:.ssh/id_rsa /root/.ssh/

systemctl daemon-reload
systemctl enable bmc.service

firewall-cmd --add-port=623/udp --permanent

## Tweaks for Bowe
# yum -y localinstall rhtbmc-1-*.rpm
# F=/usr/local/bin/bmc-wrap.bash
# [[ ! -e ${F} ]] && cp ${F} ${F}.stock
# cp /usr/share/doc/rhtbmc/bmc-wrap.bash /usr/local/bin/bmc-wrap-bash
# systemctl enable cloud-final


# Power down when done
poweroff
