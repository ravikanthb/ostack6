#!/bin/bash
templatedir='templates'

# RAZ - 021616
# Enabled to prevent TTY errors
sed -i -e 's/  requiretty/  !requiretty/' /etc/sudoers

echo -e "\n . Downloading the required images"
su - stack -c "mkdir /home/stack/images" &>/dev/null
su - stack -c "cd ~/images" &>/dev/null
su - stack -c "sudo yum -y install rhosp-director-images rhosp-director-images-ipa" &>/dev/null
su - stack -c "cp /usr/share/rhosp-director-images/overcloud-full-latest-8.0.tar ~/images/." &>/dev/null
su - stack -c "cp /usr/share/rhosp-director-images/ironic-python-agent-latest-8.0.tar ~/images/." &>/dev/null
su - stack -c "cd ~/images;tar xf overcloud-full-latest-8.0.tar;tar xf ironic-python-agent-latest-8.0.tar" &>/dev/null

echo -e "\n . Uploading the required images"
su - stack -c "source ~/stackrc;openstack overcloud image upload --image-path ~/images" &>/dev/null

echo -e "\n . Creating flavors"
source /home/stack/stackrc
nova flavor-delete compute &>/dev/null
nova flavor-delete control &>/dev/null
nova flavor-delete ceph-storage &>/dev/null
nova flavor-delete baremetal &>/dev/null
openstack flavor create --id auto --ram 2048 --disk 10 --vcpus 1 baremetal &>/dev/null
openstack flavor create --id auto --ram 4096 --disk 20 --vcpus 1 compute &>/dev/null
openstack flavor create --id auto --ram 4096 --disk 30 --vcpus 1 control &>/dev/null
openstack flavor create --id auto --ram 2048 --disk 10 --vcpus 1 ceph-storage &>/dev/null

echo -e "\n . Setting the properties of flavors"
openstack flavor set --property "cpu_arch"="x86_64" --property "capabilities:boot_option"="local" --property "capabilities:profile"="control" control &>/dev/null
openstack flavor set --property "cpu_arch"="x86_64" --property "capabilities:boot_option"="local" --property "capabilities:profile"="compute" compute &>/dev/null
openstack flavor set --property "cpu_arch"="x86_64" --property "capabilities:boot_option"="local" --property "capabilities:profile"="ceph-storage" ceph-storage &>/dev/null

# From https://bugzilla.redhat.com/show_bug.cgi?id=1234601
# iPXE doesn't boot correctly using mac= when multiple NICs are present.
echo -e "\n . Applying iPXE Fix"
cat << EOF > /usr/bin/bootif-fix
#!/usr/bin/env bash

while true;
  do find /httpboot/ -type f ! -iname "kernel" ! -iname "ramdisk" ! -iname "*.kernel" ! -iname "*.ramdisk" -exec sed -i 's|{mac|{net0/mac|g' {} +;
done
EOF
chmod a+x /usr/bin/bootif-fix
cat << EOF > /usr/lib/systemd/system/bootif-fix.service
[Unit]
Description=Automated fix for incorrect iPXE BOOFIF

[Service]
Type=simple
ExecStart=/usr/bin/bootif-fix

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload &>/dev/null
systemctl enable bootif-fix &>/dev/null
systemctl start bootif-fix &>/dev/null

echo -e "\n . Registering the overcloud nodes"
su - stack -c "curl -s -O http://materials.example.com/instackenv-threenodes.json"
su - stack -c "source ~/stackrc;openstack baremetal import --json /home/stack/instackenv-threenodes.json" &>/dev/null
su - stack -c "source ~/stackrc;openstack baremetal configure boot" &>/dev/null

echo -ne "\n . Introspecting overcloud nodes"
while true;do for s in / - \\ \|; do printf "\r$s";sleep 1;done;done &
trap 'kill $!' SIGTERM SIGKILL
su - stack -c "source ~/stackrc;openstack baremetal introspection bulk start" &>/dev/null
kill $!

echo -e "\n . Updating the node properties for deployment role"
source /home/stack/stackrc
ironic node-update compute1 add properties/capabilities='profile:compute,boot_option:local' &>/dev/null
ironic node-update controller add properties/capabilities='profile:control,boot_option:local' &>/dev/null
ironic node-update ceph add properties/capabilities='profile:ceph-storage,boot_option:local' &>/dev/null

echo -e "\n . Updating the DNS nameserver"
subnetid=$(neutron "subnet-list" | awk '/172.25.250.0/ {print $2}')
neutron subnet-update ${subnetid} --dns-nameserver 172.25.250.254 &>/dev/null

echo -e "\n . Preparing the YAML files for deployment"
su - stack -c "mkdir ${templatedir}"
su - stack -c "cp -rf /usr/share/openstack-tripleo-heat-templates/* ~/${templatedir}/" &>/dev/null
su - stack -c "curl -s -O http://materials.example.com/overcloud-heat-templates/templates-ravello.tar.bz2" &>/dev/null
su - stack -c "tar -xvjpf templates-ravello.tar.bz2" &>/dev/null
su - stack -c "cat << EOF > ~/${templatedir}/puppet/hieradata/ceph.yaml
ceph::profile::params::osd_journal_size: 1024
ceph::profile::params::osd_pool_default_pg_num: 32
ceph::profile::params::osd_pool_default_pgp_num: 32
ceph::profile::params::osd_pool_default_size: 3
ceph::profile::params::osd_pool_default_min_size: 1
ceph::profile::params::osds:
        '/dev/vdb': {}
        '/dev/vdc': {}
        '/dev/vdd': {}
ceph::profile::params::manage_repo: false
ceph::profile::params::authentication_type: cephx

ceph_classes: []

ceph_osd_selinux_permissive: true
EOF" &>/dev/null

# Deploying overcloud
echo -ne "\n . Deploying overcloud nodes"
echo -n ' '
while true;do for s in / - \\ \|; do printf "\r$s";sleep 1;done;done &
trap 'kill $!' SIGTERM SIGKILL
su - stack -c "source ~/stackrc;openstack overcloud deploy --templates ~/${templatedir} --ntp-server 172.25.250.254 --control-flavor control --compute-flavor compute --ceph-storage-flavor ceph-storage --control-scale 1 --compute-scale 1 --ceph-storage-scale 1 --neutron-tunnel-types vxlan --neutron-network-type vxlan -e ~/${templatedir}/environments/storage-environment.yaml -e ~/${templatedir}/environments/network-isolation.yaml -e ~/templates/network-environment.yaml -e ~/templates/firstboot.yaml --libvirt-type qemu" &>/dev/null

kill $!

# Stack complete status
stackstatus=$(source ~/stackrc;heat stack-list | grep overcloud | awk '{print $6}')

# Verifying the deployment
echo -e "\n . Verifying the deployment"
cmd1=$(source ~/stackrc;openstack server list | grep overcloud-controller-0 | grep -v Status | awk '{print $6}')
cmd2=$(source ~/stackrc;openstack server list | grep overcloud-novacompute-0 | grep -v Status | awk '{print $6}')
cmd3=$(source ~/stackrc;openstack server list | grep overcloud-cephstorage-0 | grep -v Status | awk '{print $6}')

# RAZ: I'd also check the Heat stack since you can have all VMs marked as ACTIVE
# while the stack remains in "CREATE_IN_PROGRESS"
if [[ ${stackstatus} == "CREATE_COMPLETE" && ${cmd1} == "ACTIVE" && ${cmd2} == "ACTIVE" && ${cmd3} == "ACTIVE" ]]; then
   echo -ne "\n Overcloud installation complete."
   echo -e "\n . Setting up the environment."
else
   echo -e "\nArgh!! Something went wrong..."
   exit
fi

# Copy the overcloudrc file to all the nodes
echo -e "\n . Copying the overcloudrc file to all overcloud nodes"
source ~/stackrc
cephip=$(openstack server list | grep "overcloud-cephstorage-0" | awk '{print $8}' | sed 's/ctlplane=//')
computeip=$(openstack server list | grep "overcloud-novacompute-0" | awk '{print $8}' | sed 's/ctlplane=//')
controllerip=$(openstack server list | grep "overcloud-controller-0" | awk '{print $8}' | sed 's/ctlplane=//')

for nodeip in ${cephip} ${computeip} ${controllerip}
do
  su - stack -c "scp -q -o StrictHostKeyChecking=no ~/overcloudrc heat-admin@${nodeip}:~"
done

# Small MTU fix on overcloud nodes to support dual-host setup
echo -ne "\n . Doing Controller post deployment changes"
su - stack -c "curl -s -O http://materials.example.com/neutron-postdeploy.sh"
su - stack -c "chmod a+x /home/stack/neutron-postdeploy.sh"
su - stack -c "/home/stack/neutron-postdeploy.sh"
su - stack -c "rm -rf /home/stack/neutron-postdeploy.sh"

# Post deployment for ceph nodes
echo -ne " . Doing Ceph post deployment changes"
su - stack -c "curl -s -O http://materials.example.com/ceph-postdeploy.sh"
su - stack -c "chmod a+x /home/stack/ceph-postdeploy.sh"
su - stack -c "/home/stack/ceph-postdeploy.sh"
su - stack -c "rm -rf /home/stack/ceph-postdeploy.sh"

# Change it back to requiretty
sed -i -e 's/!requiretty/requiretty/' /etc/sudoers

echo -e "\nCongrats!! Overcloud is now setup..."
