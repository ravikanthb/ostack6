#!/bin/bash
source /home/stack/stackrc
ctlip=$(nova list | grep overcloud-controller-0 | awk '{print $12}' | sed 's/ctlplane=//')
SSHCTRL="ssh -t -q -o StrictHostKeyChecking=no heat-admin@${ctlip}"
if ! ${SSHCTRL} "sudo grep 'dhcp-option-force=26,1300' /etc/neutron/dnsmasq-neutron.conf"; then
	${SSHCTRL} "echo 'dhcp-option-force=26,1300' | sudo tee /etc/neutron/dnsmasq-neutron.conf" &>/dev/null
	source /home/stack/stackrc && nova reboot overcloud-controller-0 &>/dev/null
	echo -ne "\n . Rebooting the Controller node"
	sleep 5
	while ! ssh -t -q -o BatchMode=yes -o ConnectTimeout=5 -o StrictHostKeyChecking=no heat-admin@${ctlip} "exit"
	do
	  echo -n "."
	  sleep 2
	done
	echo -e "\n"
fi
