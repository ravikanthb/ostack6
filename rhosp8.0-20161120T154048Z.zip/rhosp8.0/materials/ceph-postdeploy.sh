#!/bin/bash
#SK: Logic to change the crushmap to use OSD as bucket type instead of host
#http://docs.ceph.com/docs/master/rados/operations/crush-map/#crush-map-bucket-types
source /home/stack/stackrc
cephip=$(nova list | grep overcloud-cephstorage-0 | awk '{print $12}' | sed 's/ctlplane=//')
SSHCEPH="ssh -t -q -o StrictHostKeyChecking=no heat-admin@${cephip}"
${SSHCEPH} "sudo ceph osd getcrushmap -o /tmp/mycrushmap" &>/dev/null
${SSHCEPH} "sudo crushtool -d /tmp/mycrushmap > /tmp/mycrushmap.txt" &>/dev/null
${SSHCEPH} "sudo sed -i -e 's/type\ host/type\ osd/' /tmp/mycrushmap.txt" &>/dev/null
${SSHCEPH} "sudo crushtool -c /tmp/mycrushmap.txt -o /tmp/mycrushmap.new" &>/dev/null
${SSHCEPH} "sudo ceph osd setcrushmap -i /tmp/mycrushmap.new" &>/dev/null
#${SSHCEPH} "sudo reboot;exit" &>/dev/null
source /home/stack/stackrc && nova reboot overcloud-cephstorage-0 &>/dev/null
echo -ne "\n . Rebooting the Ceph node"
sleep 5
while ! ssh -t -q -o BatchMode=yes -o ConnectTimeout=5 -o StrictHostKeyChecking=no heat-admin@${cephip} "exit"
do
  echo -n "."
  sleep 2
done
echo -e "\n . Starting Ceph. It may take some time for it to start"
WAIT=0
until ${SSHCEPH} "sudo ceph -s | grep HEALTH_OK" || [ ${WAIT} -eq 20 ]
do
    sleep $(( WAIT++ ))
done
${SSHCEPH} "sudo ceph -s | grep HEALTH_OK" && echo "Ceph started" || echo "Ceph health in WARN state"
